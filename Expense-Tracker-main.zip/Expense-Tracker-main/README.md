# Expense-Tracker
Description:

You are now free from your own expense issues,here comes a Daily Expense Tracker ,to solve your Real time problems.
Benefits of this tracker system,

   1.Tracks your expense daily</br>
   2.User friendly</br>
   3.Helps to manage your expenses efficiently</br>
   4.Decrease your expenditure by sector-wise report</br>

This project uses HTML,CSS,JavaScript,JSP,Java,MYSQL.
Deployed in heroku:https://expense-today.herokuapp.com/
